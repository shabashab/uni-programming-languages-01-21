package edu.naukma.hw1;

public class Program {
  public static void main(String[] args) {
    System.out.println("Символьний: це або 1 символ Unicode, взятий в одинарні лапки");
    System.out.println("(char C=‘!’) або послідовність, яка починається з \\: (\\n – кінець");
    System.out.println("рядка; \\t – табуляція; \\’ – одинарні лапки; \\” – подвійні лапки;");
    System.out.println("\\\\ – зворотній слеш); літерал може задаватися Unicode-кодом,");
    System.out.println("напр. \\u0041 (це літера А);");
  }
}
